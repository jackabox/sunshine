<?php

namespace Adtrak\Forms\Controllers;

use Adtrak\Forms\View;
use Adtrak\Forms\Helper;
use Adtrak\Forms\Models\Form;
use Billy\Framework\Models\Option;
use PHPMailer;
use DrewM\MailChimp\MailChimp;

class MailController
{
    protected $referenceNo;
    protected $mail;
    protected $files;
    protected $mailchimp;
    protected $form;

    public $error;
    public $error_message;

    public $fromOver = false;

    /**
     * MailController constructor
     */
    public function __construct($form, $files)
    {
        $this->files = $files;
        $this->error = false;

        $this->form = $form;

        $smtp = Option::where('option_name', '=', 'apcf_options')->get();
        $smtp = unserialize($smtp[0]->option_value);

        $workedData = [];
        foreach ($smtp as $key => $option) {
            $nkey = str_replace("-", "_", $key);
            $workedData[$nkey] = $option;
        }

        $smtp = $workedData;

        $this->mail = new PHPMailer;
        $this->mail->isSMTP();
        $this->mail->Host = $smtp['smtp_host'];
        $this->mail->Port = $smtp['smtp_port'];
        $this->mail->SMTPAuth = true;
        $this->mail->Username = $smtp['smtp_username'];
        $this->mail->Password = $smtp['smtp_password'];
        if (isset($smtp['smtp_password'])) {
            $this->mail->SMTPSecure = $smtp['smtp_security'];
        } else {
            $this->mail->SMTPSecure = 'tls';
        }

        date_default_timezone_set('Europe/London');
        $date = new \DateTime();
        $this->referenceNo = $date->format('si / hd - my');
    }


    /**
     * @return ???
     */
    public function sendClientEmail($data)
    {
        # Clear recipients as Mail is potentially used twice
        $this->mail->ClearAllRecipients();

        $emailSubject = 'Adtrak Website - ' . ucfirst($this->form->name) . ' Enquiry';
        $this->mail->Subject = $emailSubject;

        $emails = unserialize($this->form->emails);

        # Check if emailTo exists and split into a comma seperated array then add to the Mail
        if (!empty($emails['emailTo'])) {
            $emailTo = explode(",", $emails['emailTo']);
            foreach ($emailTo as $email) {
                $this->mail->AddAddress($email, $email);
            }
        }
        # Check if emailCC exists and split into a comma seperated array then add to the Mail
        if (!empty($emails['emailCC'])) {
            $emailTo = explode(",", $emails['emailCC']);
            foreach ($emailTo as $email) {
                $this->mail->AddCC($email, $email);
            }
        }
        # Check if emailBCC exists and split into a comma seperated array then add to the Mail
        if (!empty($emails['emailBCC'])) {
            $emailTo = explode(",", $emails['emailBCC']);
            foreach ($emailTo as $email) {
                $this->mail->AddBCC($email, $email);
            }
        }

        foreach ($data as $fields) {
            if (filter_var($fields, FILTER_VALIDATE_EMAIL)) {
                $this->mail->FromName = $fields;
                $this->mail->From = $fields;
                $this->mail->AddReplyTo($fields, $fields);
                $fromOver = true;
                break;
            }
        }

        if (!$fromOver) {
            $this->mail->FromName = $this->mail->Username;
            $this->mail->From = $this->mail->Username;
            $this->mail->AddReplyTo($this->mail->Username, $this->mail->Username);
        }

        $build = [];

        $build['site_name'] = get_option("blogname");
        $build['subject'] = $emailSubject;
        $build['emailFrom'] = $data['acpf-email'];
        $build['referenceNo'] = $this->referenceNo;

        $n = [];
        foreach ($data as $key => $value) {
            $nkey = str_replace("acpf-", "", $key);
            $n[$nkey] = $value;
        }

        $build['rows'] = $n;

        $data = json_decode(json_encode($build), false);

        # Create the email

        ob_start();
        $template = $this->templateLocater('emailClient.php');
        include_once $template;
        $msg = ob_get_contents();
        ob_end_clean();

        $this->mail->MsgHTML($msg);

        # Check if there are attachments then loop through and add to the email
        if ($this->files) {
            for ($i=0; $i < count($this->files["upload"]); $i++) {
                foreach (array_keys($this->files['upload']['name']) as $key) {
                    $source = $this->files['upload']['tmp_name'][$key];
                    $filename = $this->files['upload']['name'][$key];
                    $filesize = $this->files['upload']['size'][$key];
                    $filetype = $this->files['upload']['type'][$key];

                    $this->mail->AddAttachment($source, $filename);
                }
            }
        }

        if (!$this->mail->Send()) {
            $this->error = true;
            $this->error_message = $this->mail->ErrorInfo;
        }
    }

    public function sendCustomerEmail($data)
    {
        # Clear recipients as Mail is used twice
        $this->mail->ClearAllRecipients();

        $emailSubject = get_option("blogname") . ' | Thanks for getting in touch!';
        $this->mail->Subject = $emailSubject;
        foreach ($data as $fields) {
            if (filter_var($fields, FILTER_VALIDATE_EMAIL)) {
                $this->mail->AddAddress($fields, $fields);
                break;
            }
        }
        $this->mail->FromName = get_option("blogname");

        $emails = unserialize($this->form->emails);
        $emailTo = explode(",", $emails['emailTo']);
        $this->mail->AddReplyTo($emailTo[0], $emailTo[0]);
        $this->mail->From = $emailTo[0];

        # Create the email

        $build = [];

        $build['site_name'] = get_option("blogname");
        $build['subject'] = $emailSubject;
        $build['emailFrom'] = $data['acpf-email'];
        $build['referenceNo'] = $this->referenceNo;

        $n = [];
        foreach ($data as $key => $value) {
            $nkey = str_replace("acpf-", "", $key);
            $n[$nkey] = $value;
        }

        $build['rows'] = $n;

        $data = json_decode(json_encode($build), false);

        # Create the email

        ob_start();
        $template = $this->templateLocater('emailCustomer.php');
        include_once $template;
        $msg = ob_get_contents();
        ob_end_clean();

        $this->mail->MsgHTML($msg);

        # Check if there are attachments then loop through and add to the email
        if ($this->files) {
            //attachment information
            for ($i=0; $i < count($this->files["upload"]); $i++) {
                foreach (array_keys($this->files['upload']['name']) as $key) {
                    $source = $this->files['upload']['tmp_name'][$key];
                    $filename = $this->files['upload']['name'][$key];
                    $filesize = $this->files['upload']['size'][$key];
                    $filetype = $this->files['upload']['type'][$key];

                    $this->mail->AddAttachment($source, $filename);
                }
            }
        }

        if (!$this->mail->Send()) {
            $this->error = true;
            $this->error_message = $this->mail->ErrorInfo;
        }
    }

    /**
    * @param $filename
    * @return string
    */
    protected function templateLocater($filename)
    {
        if ($overwrite = locate_template('adtrak-forms/' . $filename)) {
            $template = $overwrite;
        } else {
            $template = Helper::get('templates') . $filename;
        }
        return $template;
    }
}
